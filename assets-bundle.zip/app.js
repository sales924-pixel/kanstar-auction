'use strict';
/* Kanstar Daily Auction — front-end SPA (no framework). */

const I18N = {
  en: {
    brand_sub: 'DAILY AUCTION', nav_all: 'All Lots', nav_my: 'My Bids', nav_rules: 'Rules', nav_msg: 'My Messages',
    seller_login: 'Seller login',
    hero_h: 'Warehouse deals, auctioned daily', hero_p: 'Every lot is sold by Kanstar only. Each lot has its own 24-hour countdown — when it hits zero, the highest bid wins.',
    main_zone: 'Main Zone — 24-Hour Auctions', flash_zone: '5-Minute Flash Zone', flash_empty: 'No flash auctions right now. The seller will light this zone up soon.',
    current_bid: 'Current bid', starting_bid: 'Starting bid', bids: 'bids', bid: 'bid', retail: 'Retail',
    free_ship: 'FREE SHIP $20+', free_pickup: 'FREE PICKUP', time_left: 'left', ended: 'ENDED', ends_in: 'Ends in',
    view_lot: 'View & bid', photos: 'photos',
    ask: 'Ask about this lot', your_name: 'Your name', your_email: 'Your email', message: 'Message', send: 'Send',
    msg_sent: 'Message sent! Save your receipt code to see the reply:', your_code: 'Your receipt code',
    place_bid: 'Place bid', bid_amount: 'Your bid (USD)', name: 'Name', email: 'Email',
    bid_note: 'Your name and email are only used to contact you about this auction (outbid, ending soon, winning). They are never shown publicly.',
    min_next: 'Minimum next bid', you_lead: 'You are the highest bidder!', bid_ok: 'Bid placed! You are in the lead.',
    desc: 'Details', qty: 'Quantity', category: 'Category', ask_q: 'Questions about this lot?',
    mybids_h: 'My Bids', mybids_p: 'Enter the email you bid with to see your bids and wins.', load: 'Load',
    winning: 'Winning', outbid: 'Outbid', won: 'You won!', checkout: 'Check out', ordered: 'Order placed',
    no_bids: 'No bids found for this email yet.', your_wins: 'Your wins', your_bids: 'Your bids',
    rules_h: 'Auction Rules & FAQ',
    contact_h: 'Contact Us', contact_p: 'Send us a message and we will get back to you. Save the receipt code you receive — you will need it to read our reply under My Messages.',
    mymsg_h: 'My Messages', mymsg_p: 'Enter the receipt code from your message to see it and our reply.', seller_reply: 'Kanstar replied', no_reply: 'No reply yet — check back soon.',
    code: 'Receipt code', check: 'Check',
    checkout_h: 'Checkout', delivery: 'Delivery', pickup: 'Warehouse pickup — FREE', ship: 'Ship it to me',
    pickup_at: 'Pickup at', phone: 'Phone number (for pickup / delivery contact)', state: 'State (2 letters, e.g. CA)',
    address: 'Shipping address', item: 'Winning bid', shipping: 'Shipping', tax: 'CA sales tax (9.5%)', total: 'Total',
    place_order: 'Place order', order_ok: 'Order placed! We will contact you by phone/email to arrange pickup or delivery.',
    ship_note: 'Shipping is FREE on wins of $20 or more, otherwise +$5. Local delivery next day; nationwide 3–7 days.',
    tax_note: 'California orders are subject to sales tax.',
    seller_h: 'Seller Backend', passcode: 'Seller passcode', unlock: 'Unlock', lock: 'Lock',
    wrong_pass: 'Wrong passcode.', tab_list: 'List an item', tab_inbox: 'Inbox', tab_traffic: 'Traffic', tab_orders: 'Orders',
    f_title: 'Title', f_sub: 'Subtitle', f_cat: 'Category', f_zone: 'Zone', f_main: 'Main (24 hours)', f_flash: 'Flash (5 minutes)',
    f_start: 'Starting price (USD)', f_retail: 'Retail price (USD, optional)', f_qty: 'Quantity note', f_desc: 'Description',
    f_photos: 'Photos (up to 8, first = cover)', list_it: 'List it', listed_ok: 'Lot listed! It is live now.',
    inbox_empty: 'No messages yet.', reply: 'Reply', reply_send: 'Send reply', mark_read: 'Mark all read',
    orders_empty: 'No orders yet.',
    t_today: 'Visitors today', t_total: 'Total visitors', t_pages: 'Page views', t_lots: 'Lot views', t_bids: 'Total bids',
    t_hours: "Today's traffic by hour", t_by_lot: 'Views & bids by lot', t_by_state: 'Visitors by state',
    views: 'Views', visitors: 'visitors', loading: 'Loading…', back: '← Back to lots',
    ends_soon: 'Ending soon', new_today: 'New today', per_lot_time: 'Each lot runs on its own 24-hour clock.',
  },
  es: {
    brand_sub: 'SUBASTA DIARIA', nav_all: 'Todos los lotes', nav_my: 'Mis ofertas', nav_rules: 'Reglas', nav_msg: 'Mis mensajes',
    seller_login: 'Acceso del vendedor',
    hero_h: 'Ofertas de almacén, subastadas cada día', hero_p: 'Todos los lotes los vende solo Kanstar. Cada lote tiene su propia cuenta regresiva de 24 horas: cuando llega a cero, gana la oferta más alta.',
    main_zone: 'Zona principal — Subastas de 24 horas', flash_zone: 'Zona Flash de 5 minutos', flash_empty: 'No hay subastas flash ahora. El vendedor activará esta zona pronto.',
    current_bid: 'Oferta actual', starting_bid: 'Oferta inicial', bids: 'ofertas', bid: 'oferta', retail: 'Precio de lista',
    free_ship: 'ENVÍO GRATIS $20+', free_pickup: 'RECOGIDA GRATIS', time_left: 'restante', ended: 'TERMINADO', ends_in: 'Termina en',
    view_lot: 'Ver y ofertar', photos: 'fotos',
    ask: 'Preguntar por este lote', your_name: 'Tu nombre', your_email: 'Tu correo', message: 'Mensaje', send: 'Enviar',
    msg_sent: '¡Mensaje enviado! Guarda tu código de recibo para ver la respuesta:', your_code: 'Tu código de recibo',
    place_bid: 'Ofertar', bid_amount: 'Tu oferta (USD)', name: 'Nombre', email: 'Correo electrónico',
    bid_note: 'Tu nombre y correo solo se usan para avisarte sobre esta subasta (superado, por terminar, ganador). Nunca se muestran en público.',
    min_next: 'Oferta mínima siguiente', you_lead: '¡Vas ganando!', bid_ok: '¡Oferta registrada! Vas en primer lugar.',
    desc: 'Detalles', qty: 'Cantidad', category: 'Categoría', ask_q: '¿Preguntas sobre este lote?',
    mybids_h: 'Mis ofertas', mybids_p: 'Escribe el correo con el que ofertaste para ver tus ofertas y premios.', load: 'Cargar',
    winning: 'Ganando', outbid: 'Superado', won: '¡Ganaste!', checkout: 'Pagar', ordered: 'Pedido hecho',
    no_bids: 'Aún no hay ofertas con este correo.', your_wins: 'Tus premios', your_bids: 'Tus ofertas',
    rules_h: 'Reglas de la subasta y preguntas frecuentes',
    contact_h: 'Contáctanos', contact_p: 'Envíanos un mensaje y te responderemos. Guarda el código de recibo: lo necesitarás para leer nuestra respuesta en Mis mensajes.',
    mymsg_h: 'Mis mensajes', mymsg_p: 'Escribe el código de recibo de tu mensaje para verlo y leer nuestra respuesta.', seller_reply: 'Kanstar respondió', no_reply: 'Aún sin respuesta — vuelve pronto.',
    code: 'Código de recibo', check: 'Consultar',
    checkout_h: 'Pagar', delivery: 'Entrega', pickup: 'Recogida en almacén — GRATIS', ship: 'Envío a domicilio',
    pickup_at: 'Recogida en', phone: 'Teléfono (para coordinar recogida / envío)', state: 'Estado (2 letras, ej. CA)',
    address: 'Dirección de envío', item: 'Oferta ganadora', shipping: 'Envío', tax: 'Impuesto de CA (9.5%)', total: 'Total',
    place_order: 'Hacer el pedido', order_ok: '¡Pedido hecho! Te contactaremos por teléfono/correo para coordinar la recogida o el envío.',
    ship_note: 'El envío es GRATIS en premios de $20 o más; si no, +$5. Entrega local al día siguiente; resto del país 3–7 días.',
    tax_note: 'Los pedidos de California están sujetos a impuesto sobre las ventas.',
    seller_h: 'Panel del vendedor', passcode: 'Clave del vendedor', unlock: 'Entrar', lock: 'Bloquear',
    wrong_pass: 'Clave incorrecta.', tab_list: 'Publicar un lote', tab_inbox: 'Bandeja', tab_traffic: 'Tráfico', tab_orders: 'Pedidos',
    f_title: 'Título', f_sub: 'Subtítulo', f_cat: 'Categoría', f_zone: 'Zona', f_main: 'Principal (24 horas)', f_flash: 'Flash (5 minutos)',
    f_start: 'Precio inicial (USD)', f_retail: 'Precio de lista (USD, opcional)', f_qty: 'Nota de cantidad', f_desc: 'Descripción',
    f_photos: 'Fotos (hasta 8, la primera es la portada)', list_it: 'Publicar', listed_ok: '¡Lote publicado! Ya está en vivo.',
    inbox_empty: 'Aún no hay mensajes.', reply: 'Respuesta', reply_send: 'Enviar respuesta', mark_read: 'Marcar todo leído',
    orders_empty: 'Aún no hay pedidos.',
    t_today: 'Visitantes hoy', t_total: 'Visitantes totales', t_pages: 'Vistas de página', t_lots: 'Vistas de lotes', t_bids: 'Ofertas totales',
    t_hours: 'Tráfico de hoy por hora', t_by_lot: 'Vistas y ofertas por lote', t_by_state: 'Visitantes por estado',
    views: 'Vistas', visitors: 'visitantes', loading: 'Cargando…', back: '← Volver a los lotes',
    ends_soon: 'Termina pronto', new_today: 'Nuevo hoy', per_lot_time: 'Cada lote corre con su propio reloj de 24 horas.',
  },
};
let lang = localStorage.getItem('kda_lang') || 'en';
const t = (k) => (I18N[lang] && I18N[lang][k]) || I18N.en[k] || k;
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const fmt = (c) => '$' + (c / 100).toFixed(2);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const app = $('#app');

function applyI18nStatic() {
  document.documentElement.lang = lang;
  $$('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  $('#lang-en').classList.toggle('on', lang === 'en');
  $('#lang-es').classList.toggle('on', lang === 'es');
}
$('#lang-en').addEventListener('click', () => { lang = 'en'; localStorage.setItem('kda_lang', 'en'); applyI18nStatic(); render(); });
$('#lang-es').addEventListener('click', () => { lang = 'es'; localStorage.setItem('kda_lang', 'es'); applyI18nStatic(); render(); });

function toast(msg) {
  const el = $('#toast'); el.textContent = msg; el.hidden = false;
  clearTimeout(el._t); el._t = setTimeout(() => { el.hidden = true; }, 4200);
}
async function api(pathname, opts = {}) {
  const r = await fetch(pathname, { headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) }, ...opts });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || 'error'), { data: j, status: r.status });
  return j;
}
function track(type, lotId) {
  fetch('/api/track', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type, lotId: lotId || null }) }).catch(() => {});
}
const identity = () => { try { return JSON.parse(localStorage.getItem('kda_bidder') || 'null'); } catch { return null; } };
const setIdentity = (name, email) => localStorage.setItem('kda_bidder', JSON.stringify({ name, email }));

/* countdown ticker */
let serverOffset = 0;
const nowMs = () => Date.now() + serverOffset;
function fmtLeft(ms) {
  if (ms <= 0) return t('ended');
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
  const p2 = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}h ${p2(m)}m ${p2(ss)}s` : `${m}m ${p2(ss)}s`;
}
setInterval(() => {
  $$('[data-ends]').forEach((el) => {
    const ends = Number(el.dataset.ends), created = Number(el.dataset.created || 0), dur = Number(el.dataset.dur || 0);
    const left = ends - nowMs();
    if (el.classList.contains('countbar')) {
      const fill = el.querySelector('.fill'), txt = el.querySelector('.txt');
      const pct = dur > 0 ? Math.max(0, Math.min(100, (left / dur) * 100)) : 0;
      if (fill) fill.style.width = pct + '%';
      el.classList.toggle('hot', left > 0 && left < 2 * 3600 * 1000);
      if (txt) txt.textContent = left > 0 ? `${fmtLeft(left)} · ${pct.toFixed(0)}%` : t('ended');
    } else {
      el.textContent = left > 0 ? fmtLeft(left) : t('ended');
      el.classList.toggle('hot', left > 0 && left < 2 * 3600 * 1000);
    }
  });
}, 1000);
function countbar(lot) {
  const left = lot.ends_at - nowMs();
  const pct = lot.duration_ms > 0 ? Math.max(0, Math.min(100, (left / lot.duration_ms) * 100)) : 0;
  return `<div class="countbar ${left > 0 && left < 2 * 3600 * 1000 ? 'hot' : ''}" data-ends="${lot.ends_at}" data-created="${lot.created_at}" data-dur="${lot.duration_ms}">
    <div class="fill" style="width:${pct}%"></div><div class="txt">${left > 0 ? `${fmtLeft(left)} · ${pct.toFixed(0)}%` : t('ended')}</div></div>`;
}

/* ------------------------------- pages ------------------------------- */
function lotCard(lot) {
  const ended = lot.status === 'ended' || lot.ends_at <= nowMs();
  return `<article class="card">
    <a class="photo" href="#/lot/${lot.id}"><img src="${esc(lot.images[0] || '')}" alt="${esc(lot.title)}" loading="lazy"></a>
    ${countbar(lot)}
    <div class="body">
      <h3><a href="#/lot/${lot.id}">${esc(lot.title)}</a></h3>
      <div class="sub">${esc(lot.subtitle)}</div>
      <div class="badges"><span class="chip ship">${t('free_ship')}</span><span class="chip ship">${t('free_pickup')}</span>${lot.qty_note ? `<span class="chip">${esc(lot.qty_note)}</span>` : ''}</div>
      <div class="price-row"><span class="price">${fmt(lot.current_cents)}</span>${lot.retail_cents ? `<span class="retail">${fmt(lot.retail_cents)}</span>` : ''}</div>
      <div class="meta"><span>${lot.has_bids ? t('current_bid') : t('starting_bid')} · ${lot.bid_count} ${lot.bid_count === 1 ? t('bid') : t('bids')}</span>
      <span class="${ended ? 'ended-tag' : ''}" data-ends="${lot.ends_at}">${ended ? t('ended') : fmtLeft(lot.ends_at - nowMs())}</span></div>
    </div></article>`;
}

async function pageHome() {
  app.innerHTML = `<div class="hero"><h1>${t('hero_h')}</h1><p>${t('hero_p')}</p></div><p class="note">${t('loading')}</p>`;
  const data = await api('/api/lots');
  serverOffset = data.now - Date.now();
  const main = data.lots.filter((l) => l.zone === 'main');
  const flash = data.lots.filter((l) => l.zone === 'flash');
  app.innerHTML = `
    <div class="hero"><h1>${t('hero_h')}</h1><p>${t('hero_p')}</p></div>
    <h2 class="zone-title"><span class="dot"></span>${t('main_zone')}</h2>
    <p class="note" style="margin-top:-8px">${t('per_lot_time')}</p>
    <div class="grid">${main.map(lotCard).join('')}</div>
    <section class="flash-zone">
      <h2 class="zone-title"><span class="flash-badge">FLASH</span>${t('flash_zone')}</h2>
      ${flash.length ? `<div class="grid">${flash.map(lotCard).join('')}</div>` : `<p class="note">${t('flash_empty')}</p>`}
    </section>`;
  track('page');
}

async function pageLot(id) {
  app.innerHTML = `<p class="note">${t('loading')}</p>`;
  const data = await api('/api/lots/' + id);
  serverOffset = data.now - Date.now();
  const lot = data.lot;
  const me = identity();
  const ended = lot.status === 'ended' || lot.ends_at <= nowMs();
  const minNext = lot.has_bids ? lot.current_cents + 100 : lot.start_cents;
  let idx = 0;
  app.innerHTML = `
    <p><a href="#/">${t('back')}</a></p>
    <div class="detail">
      <div class="gallery">
        <div class="main-photo">
          <img id="g-main" src="${esc(lot.images[0] || '')}" alt="${esc(lot.title)}">
          ${lot.images.length > 1 ? `<button class="nav-btn prev" id="g-prev" aria-label="Previous">‹</button><button class="nav-btn next" id="g-next" aria-label="Next">›</button>
          <span class="counter" id="g-count">1 / ${lot.images.length}</span>` : ''}
        </div>
        <div class="thumbs">${lot.images.map((src, i) => `<button data-i="${i}" class="${i === 0 ? 'on' : ''}"><img src="${esc(src)}" alt=""></button>`).join('')}</div>
      </div>
      <div>
        <div class="panel">
          <h1>${esc(lot.title)}</h1>
          <p class="sub">${esc(lot.subtitle)}</p>
          <div class="kv"><span>${lot.has_bids ? t('current_bid') : t('starting_bid')}</span><strong style="font-size:1.3rem">${fmt(lot.current_cents)}</strong></div>
          ${lot.retail_cents ? `<div class="kv"><span>${t('retail')}</span><span style="text-decoration:line-through;color:var(--muted)">${fmt(lot.retail_cents)}</span></div>` : ''}
          <div class="kv"><span>${t('bids')}</span><span>${lot.bid_count}</span></div>
          <div class="kv"><span>${t('qty')}</span><span>${esc(lot.qty_note || '—')}</span></div>
          <div class="kv"><span>${t('category')}</span><span>${esc(lot.category)}</span></div>
          <div class="kv"><span>${t('ends_in')}</span><span class="big-count" data-ends="${lot.ends_at}">${fmtLeft(lot.ends_at - nowMs())}</span></div>
          ${countbar(lot)}
          <hr class="hr">
          ${ended ? `<p class="ended-tag">${t('ended')}</p>` : `
          <form id="bid-form">
            <label>${t('name')}</label><input id="b-name" required value="${esc(me ? me.name : '')}" autocomplete="name">
            <label>${t('email')}</label><input id="b-email" type="email" required value="${esc(me ? me.email : '')}" autocomplete="email">
            <label>${t('bid_amount')} — ${t('min_next')}: ${fmt(minNext)}</label>
            <input id="b-amount" type="number" step="0.01" min="${(minNext / 100).toFixed(2)}" value="${(minNext / 100).toFixed(2)}" required>
            <p class="note">${t('bid_note')}</p>
            <p class="error" id="bid-err"></p>
            <button class="btn" type="submit">${t('place_bid')}</button>
          </form>`}
        </div>
        <div class="panel" style="margin-top:16px">
          <h3 style="margin-top:0">${t('desc')}</h3>
          <p class="note" style="color:var(--text)">${esc(lot.description)}</p>
          <p class="note">${t('ship_note')}<br>${t('tax_note')}</p>
        </div>
        <div class="panel" style="margin-top:16px">
          <h3 style="margin-top:0">${t('ask_q')}</h3>
          ${askFormHtml(lot.id)}
        </div>
      </div>
    </div>`;
  track('lot', lot.id);
  const setIdx = (i) => {
    idx = (i + lot.images.length) % lot.images.length;
    $('#g-main').src = lot.images[idx];
    const c = $('#g-count'); if (c) c.textContent = `${idx + 1} / ${lot.images.length}`;
    $$('.thumbs button').forEach((b, bi) => b.classList.toggle('on', bi === idx));
  };
  if (lot.images.length > 1) {
    $('#g-prev').addEventListener('click', () => setIdx(idx - 1));
    $('#g-next').addEventListener('click', () => setIdx(idx + 1));
    $$('.thumbs button').forEach((b) => b.addEventListener('click', () => setIdx(Number(b.dataset.i))));
  }
  bindAskForm(lot.id);
  const form = $('#bid-form');
  if (form) form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = $('#b-name').value.trim(), email = $('#b-email').value.trim(), amount = Number($('#b-amount').value);
    try {
      const r = await api('/api/bid', { method: 'POST', body: JSON.stringify({ lotId: lot.id, name, email, amount }) });
      setIdentity(name, email.toLowerCase());
      toast(t('bid_ok'));
      pageLot(id);
    } catch (err) {
      $('#bid-err').textContent = err.data && err.data.error === 'bid_too_low'
        ? `${t('min_next')}: ${fmt(err.data.min_cents)}` : (err.data.error || 'Error');
    }
  });
}

function askFormHtml(lotId) {
  const me = identity();
  return `<form class="ask-form" data-lot="${lotId || ''}">
    <label>${t('your_name')}</label><input class="a-name" required value="${esc(me ? me.name : '')}">
    <label>${t('your_email')}</label><input class="a-email" type="email" required value="${esc(me ? me.email : '')}">
    <label>${t('message')}</label><textarea class="a-body" rows="3" required></textarea>
    <p class="error a-err"></p><p class="success a-ok"></p>
    <button class="btn secondary" type="submit">${lotId ? t('ask') : t('send')}</button>
  </form>`;
}
function bindAskForm(lotId, root) {
  $$('.ask-form', root || document).forEach((f) => {
    if (f._bound) return; f._bound = true;
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = {
        lotId: lotId || (f.dataset.lot ? Number(f.dataset.lot) : null),
        name: f.querySelector('.a-name').value.trim(),
        email: f.querySelector('.a-email').value.trim(),
        body: f.querySelector('.a-body').value.trim(),
      };
      try {
        const r = await api('/api/messages', { method: 'POST', body: JSON.stringify(payload) });
        f.querySelector('.a-ok').textContent = `${t('msg_sent')} ${r.receipt_code}`;
        f.querySelector('.a-body').value = '';
      } catch (err) { f.querySelector('.a-err').textContent = err.data.error || 'Error'; }
    });
  });
}

async function pageMyBids() {
  const me = identity();
  app.innerHTML = `<h1>${t('mybids_h')}</h1><p class="note">${t('mybids_p')}</p>
    <form id="mb-form" style="max-width:420px"><label>${t('email')}</label>
    <input id="mb-email" type="email" required value="${esc(me ? me.email : '')}">
    <p class="error" id="mb-err"></p><button class="btn" type="submit">${t('load')}</button></form>
    <div id="mb-out" style="margin-top:20px"></div>`;
  track('page');
  $('#mb-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = $('#mb-email').value.trim().toLowerCase();
    try {
      const data = await api('/api/my/bids?email=' + encodeURIComponent(email));
      const out = $('#mb-out');
      if (!data.bids.length && !data.wins.length) { out.innerHTML = `<div class="empty">${t('no_bids')}</div>`; return; }
      const myTop = (b) => b.amount_cents >= b.top_cents;
      out.innerHTML = `
        ${data.wins.length ? `<h2>${t('your_wins')}</h2>` + data.wins.map((w) => `
          <div class="msg" style="display:flex;gap:14px;align-items:center">
            ${w.images[0] ? `<img class="thumb-sm" src="${esc(w.images[0])}" alt="">` : ''}
            <div style="flex:1"><strong>${esc(w.title)}</strong><br><span class="success">${t('won')} ${fmt(w.amount_cents)}</span></div>
            ${w.order_id ? `<span class="chip">${t('ordered')} #${w.order_id}</span>` : `<a class="btn small" style="width:auto" href="#/checkout/${w.win_id}">${t('checkout')}</a>`}
          </div>`).join('') : ''}
        <h2>${t('your_bids')}</h2>
        <table><tr><th>Lot</th><th>${t('bid_amount')}</th><th>${t('current_bid')}</th><th></th></tr>
        ${data.bids.map((b) => `<tr><td><a href="#/lot/${b.lot_id}">${esc(b.title)}</a></td><td>${fmt(b.amount_cents)}</td><td>${fmt(b.top_cents)}</td>
          <td>${b.status === 'ended' ? '' : (myTop(b) ? `<span class="success">${t('winning')}</span>` : `<span style="color:#ff8b6b">${t('outbid')}</span>`)}</td></tr>`).join('')}
        </table>`;
    } catch (err) { $('#mb-err').textContent = err.data.error || 'Error'; }
  });
  if (me) $('#mb-form').dispatchEvent(new Event('submit'));
}

async function pageCheckout(winId) {
  const me = identity();
  app.innerHTML = `<h1>${t('checkout_h')}</h1><p class="note">${t('loading')}</p>`;
  track('page');
  if (!me) { app.innerHTML = `<h1>${t('checkout_h')}</h1><div class="empty">${t('mybids_p')} <a href="#/my-bids">${t('nav_my')}</a></div>`; return; }
  const data = await api('/api/my/bids?email=' + encodeURIComponent(me.email));
  const win = data.wins.find((w) => w.win_id === winId);
  if (!win) { app.innerHTML = `<div class="empty">${t('no_bids')}</div>`; return; }
  const item = win.amount_cents;
  app.innerHTML = `<h1>${t('checkout_h')}</h1>
    <div class="panel" style="max-width:560px">
      <div style="display:flex;gap:14px;align-items:center;margin-bottom:8px">
        ${win.images[0] ? `<img class="thumb-sm" src="${esc(win.images[0])}" alt="">` : ''}<strong>${esc(win.title)}</strong>
      </div>
      <form id="co-form">
        <label>${t('delivery')}</label>
        <select id="co-method"><option value="pickup">${t('pickup')}</option><option value="ship">${t('ship')}</option></select>
        <p class="note" id="co-pickup-note">${t('pickup_at')}: 1065 S Vail Ave, Montebello, CA 90640</p>
        <div id="co-ship-fields" hidden>
          <label>${t('state')}</label><input id="co-state" maxlength="2" placeholder="CA">
          <label>${t('address')}</label><textarea id="co-address" rows="2"></textarea>
        </div>
        <label>${t('phone')}</label><input id="co-phone" type="tel" placeholder="(626) 555-0123" required>
        <hr class="hr">
        <div class="kv"><span>${t('item')}</span><span>${fmt(item)}</span></div>
        <div class="kv"><span>${t('shipping')}</span><span id="q-ship">—</span></div>
        <div class="kv"><span>${t('tax')}</span><span id="q-tax">—</span></div>
        <div class="kv total"><span>${t('total')}</span><span id="q-total">—</span></div>
        <p class="note">${t('ship_note')}<br>${t('tax_note')}</p>
        <p class="error" id="co-err"></p><p class="success" id="co-ok"></p>
        <button class="btn" type="submit">${t('place_order')}</button>
      </form>
    </div>`;
  const quote = async () => {
    const method = $('#co-method').value;
    $('#co-ship-fields').hidden = method !== 'ship';
    $('#co-pickup-note').hidden = method === 'ship';
    const q = await api('/api/checkout/quote', { method: 'POST', body: JSON.stringify({ item_cents: item, method, state: $('#co-state').value }) });
    $('#q-ship').textContent = q.shipping_cents === 0 ? 'FREE' : fmt(q.shipping_cents);
    $('#q-tax').textContent = fmt(q.tax_cents);
    $('#q-total').textContent = fmt(q.total_cents);
  };
  $('#co-method').addEventListener('change', quote);
  $('#co-state').addEventListener('input', quote);
  quote();
  $('#co-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await api('/api/checkout', {
        method: 'POST',
        body: JSON.stringify({ winId, email: me.email, phone: $('#co-phone').value, method: $('#co-method').value, state: $('#co-state').value, address: $('#co-address').value }),
      });
      $('#co-ok').textContent = `${t('order_ok')} (#${r.order_id} · ${fmt(r.total_cents)})`;
      e.target.querySelector('button[type=submit]').disabled = true;
    } catch (err) { $('#co-err').textContent = err.data.error || 'Error'; }
  });
}

function pageRules() {
  const en = lang === 'en';
  app.innerHTML = `<h1>${t('rules_h')}</h1><div class="panel" style="max-width:820px;line-height:1.65">
    ${en ? `
    <h3>One Seller: Kanstar</h3><p>This is Kanstar's own warehouse auction. Only Kanstar sells here — visitors cannot list items. Every lot is warehouse stock sold as pictured.</p>
    <h3>How bidding works</h3><p>Each main-zone lot runs on its own 24-hour countdown from the time it is listed. Flash-zone lots run 5-minute rounds; a bid in the last 30 seconds extends that round by 30 seconds, and a new round starts automatically when one closes. To bid, leave your name and email so we can notify you if you are outbid, if a lot is ending soon, and if you win. Your contact details are never shown publicly.</p>
    <h3>Pickup & shipping</h3><p>Winners may pick up FREE at our warehouse: 1065 S Vail Ave, Montebello, CA 90640 — at any winning price. Or choose shipping at checkout: shipping is FREE when the winning bid is $20 or more; below $20 a $5 shipping fee applies. Local delivery is next day; nationwide delivery takes 3–7 days. A phone number is collected at checkout so we can reach you about pickup or delivery.</p>
    <h3>Sales tax</h3><p>California orders are subject to sales tax. If your order is picked up at the warehouse or shipped to a California address, 9.5% sales tax is added to the item price (shipping is not taxed). Orders shipped outside California are not taxed.</p>
    <h3>Questions</h3><p>Use “Ask about this lot” on any lot page or the Contact link in the footer. You will get a receipt code — keep it to read our reply under My Messages.</p>`
    : `
    <h3>Un solo vendedor: Kanstar</h3><p>Esta es la subasta del almacén de Kanstar. Solo Kanstar vende aquí: los visitantes no pueden publicar lotes. Cada lote es inventario del almacén y se vende tal como se muestra en las fotos.</p>
    <h3>Cómo funciona la subasta</h3><p>Cada lote de la zona principal corre con su propia cuenta regresiva de 24 horas desde que se publica. Los lotes de la zona flash corren rondas de 5 minutos; una oferta en los últimos 30 segundos extiende la ronda 30 segundos, y al cerrar una ronda empieza otra automáticamente. Para ofertar, deja tu nombre y correo para poder avisarte si te superan, si un lote está por terminar y si ganas. Tus datos nunca se muestran en público.</p>
    <h3>Recogida y envío</h3><p>Los ganadores pueden recoger GRATIS en nuestro almacén: 1065 S Vail Ave, Montebello, CA 90640, con cualquier precio ganador. O elige envío al pagar: el envío es GRATIS cuando la oferta ganadora es de $20 o más; por debajo de $20 se aplica un cargo de $5. Entrega local al día siguiente; resto del país en 3–7 días. Al pagar se pide un teléfono para contactarte sobre la recogida o el envío.</p>
    <h3>Impuesto sobre las ventas</h3><p>Los pedidos de California están sujetos a impuesto sobre las ventas. Si recoges en el almacén o el envío va a una dirección de California, se agrega 9.5% de impuesto al precio del artículo (el envío no paga impuesto). Los envíos fuera de California no pagan impuesto.</p>
    <h3>Preguntas</h3><p>Usa «Preguntar por este lote» en cualquier lote o el enlace de contacto en el pie de página. Recibirás un código de recibo: guárdalo para leer nuestra respuesta en Mis mensajes.</p>`}
  </div>`;
  track('page');
}

function pageContact() {
  app.innerHTML = `<h1>${t('contact_h')}</h1><p class="note">${t('contact_p')}</p><div style="max-width:520px">${askFormHtml(null)}</div>`;
  bindAskForm(null);
  track('page');
}

function pageMyMessages() {
  app.innerHTML = `<h1>${t('mymsg_h')}</h1><p class="note">${t('mymsg_p')}</p>
    <form id="mm-form" style="max-width:420px"><label>${t('code')}</label>
    <input id="mm-code" required placeholder="A1B2C3D4E5F6" style="text-transform:uppercase">
    <p class="error" id="mm-err"></p><button class="btn" type="submit">${t('check')}</button></form>
    <div id="mm-out" style="margin-top:18px;max-width:640px"></div>`;
  track('page');
  $('#mm-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await api('/api/messages/by-code/' + encodeURIComponent($('#mm-code').value.trim().toUpperCase()));
      const m = r.message;
      $('#mm-out').innerHTML = `<div class="msg">
        ${m.lot_title ? `<div><strong>${esc(m.lot_title)}</strong></div>` : ''}
        <p>${esc(m.body)}</p>
        ${m.seller_reply ? `<div class="reply"><strong>${t('seller_reply')}:</strong><br>${esc(m.seller_reply)}</div>` : `<p class="note">${t('no_reply')}</p>`}
      </div>`;
    } catch (err) { $('#mm-err').textContent = err.data.error || 'Error'; }
  });
}

/* --------------------------- seller backend -------------------------- */
const sellerPass = () => localStorage.getItem('kda_seller') || '';
const sellerHeaders = () => ({ 'x-seller-passcode': sellerPass() });

async function pageSeller() {
  if (!sellerPass()) {
    app.innerHTML = `<h1>${t('seller_h')}</h1>
      <form id="gate" style="max-width:360px"><label>${t('passcode')}</label>
      <input id="gate-pw" type="password" autocomplete="current-password">
      <p class="error" id="gate-err"></p><button class="btn" type="submit">${t('unlock')}</button></form>`;
    $('#gate').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await api('/api/seller/auth', { method: 'POST', body: JSON.stringify({ passcode: $('#gate-pw').value }) });
        localStorage.setItem('kda_seller', $('#gate-pw').value); // remembered on this device only
        pageSeller();
      } catch { $('#gate-err').textContent = t('wrong_pass'); }
    });
    return;
  }
  let unread = 0;
  try { unread = (await api('/api/seller/unread', { headers: sellerHeaders() })).unread; } catch { localStorage.removeItem('kda_seller'); return pageSeller(); }
  app.innerHTML = `<h1>${t('seller_h')}</h1>
    <div class="tabs">
      <button data-tab="list" class="on">${t('tab_list')}</button>
      <button data-tab="inbox">${t('tab_inbox')}${unread ? `<span class="badge">${unread}</span>` : ''}</button>
      <button data-tab="orders">${t('tab_orders')}</button>
      <button data-tab="traffic">${t('tab_traffic')}</button>
      <button id="lock-btn" style="margin-left:auto">${t('lock')}</button>
    </div><div id="seller-body"></div>`;
  $('#lock-btn').addEventListener('click', () => { localStorage.removeItem('kda_seller'); location.hash = '#/'; });
  $$('.tabs button[data-tab]').forEach((b) => b.addEventListener('click', () => {
    $$('.tabs button[data-tab]').forEach((x) => x.classList.toggle('on', x === b));
    sellerTab(b.dataset.tab);
  }));
  sellerTab('list');
}

async function sellerTab(tab) {
  const body = $('#seller-body');
  if (tab === 'list') {
    body.innerHTML = `<form id="list-form" style="max-width:560px">
      <label>${t('f_title')}</label><input id="l-title" required>
      <label>${t('f_sub')}</label><input id="l-sub">
      <div class="two-col"><div><label>${t('f_cat')}</label><input id="l-cat"></div>
      <div><label>${t('f_qty')}</label><input id="l-qty"></div></div>
      <div class="two-col"><div><label>${t('f_start')}</label><input id="l-start" type="number" step="0.01" min="1" required></div>
      <div><label>${t('f_retail')}</label><input id="l-retail" type="number" step="0.01" min="0"></div></div>
      <label>${t('f_zone')}</label><select id="l-zone"><option value="main">${t('f_main')}</option><option value="flash">${t('f_flash')}</option></select>
      <label>${t('f_desc')}</label><textarea id="l-desc" rows="3"></textarea>
      <label>${t('f_photos')}</label><input id="l-photos" type="file" accept="image/*" multiple>
      <p class="error" id="l-err"></p><p class="success" id="l-ok"></p>
      <button class="btn" type="submit">${t('list_it')}</button></form>`;
    $('#list-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const files = Array.from($('#l-photos').files).slice(0, 8);
      const images = await Promise.all(files.map((f) => new Promise((res) => {
        const rd = new FileReader(); rd.onload = () => res(rd.result); rd.onerror = () => res(null); rd.readAsDataURL(f);
      })));
      try {
        await api('/api/seller/lots', {
          method: 'POST', headers: sellerHeaders(),
          body: JSON.stringify({
            title: $('#l-title').value, subtitle: $('#l-sub').value, category: $('#l-cat').value,
            qty_note: $('#l-qty').value, start: Number($('#l-start').value),
            retail: $('#l-retail').value ? Number($('#l-retail').value) : null,
            zone: $('#l-zone').value, description: $('#l-desc').value, images: images.filter(Boolean),
          }),
        });
        $('#l-ok').textContent = t('listed_ok'); e.target.reset();
      } catch (err) { $('#l-err').textContent = err.data.error || 'Error'; }
    });
  }
  if (tab === 'inbox') {
    const data = await api('/api/seller/inbox', { headers: sellerHeaders() });
    body.innerHTML = (data.messages.length ? '' : `<div class="empty">${t('inbox_empty')}</div>`) +
      `<p><button class="btn small secondary" id="mark-read">${t('mark_read')}</button></p>` +
      data.messages.map((m) => `<div class="msg">
        <div><strong>${esc(m.name)}</strong> <span style="color:var(--muted)">${esc(m.email)} · ${new Date(m.created_at).toLocaleString()} ${m.is_read ? '' : '· 🔴'}</span></div>
        ${m.lot_title ? `<div class="note">${esc(m.lot_title)}</div>` : ''}
        <p>${esc(m.body)}</p>
        <div class="note">${t('your_code')}: ${esc(m.receipt_code)}</div>
        ${m.seller_reply ? `<div class="reply"><strong>${t('seller_reply')}:</strong><br>${esc(m.seller_reply)}</div>` : `
        <form class="reply-form" data-id="${m.id}"><label>${t('reply')}</label>
        <textarea rows="2" required></textarea><p style="margin-top:8px"><button class="btn small" type="submit">${t('reply_send')}</button></p></form>`}
      </div>`).join('');
    $('#mark-read').addEventListener('click', async () => { await api('/api/seller/inbox/read', { method: 'POST', headers: sellerHeaders(), body: '{}' }); pageSeller(); });
    $$('.reply-form', body).forEach((f) => f.addEventListener('submit', async (e) => {
      e.preventDefault();
      await api('/api/seller/inbox/reply', { method: 'POST', headers: sellerHeaders(), body: JSON.stringify({ id: Number(f.dataset.id), reply: f.querySelector('textarea').value }) });
      sellerTab('inbox');
    }));
  }
  if (tab === 'orders') {
    const data = await api('/api/seller/orders', { headers: sellerHeaders() });
    body.innerHTML = data.orders.length ? `<table><tr><th>#</th><th>Lot</th><th>Buyer</th><th>${t('delivery')}</th><th>${t('item')}</th><th>${t('shipping')}</th><th>${t('tax')}</th><th>${t('total')}</th></tr>
      ${data.orders.map((o) => `<tr><td>${o.id}</td><td>${esc(o.title)}</td><td>${esc(o.buyer_name)}<br><span class="note">${esc(o.buyer_email)}<br>${esc(o.phone)}</span></td>
      <td>${o.method === 'pickup' ? t('pickup') : `${t('ship')} → ${esc(o.dest_state)}<br><span class="note">${esc(o.address)}</span>`}</td>
      <td>${fmt(o.item_cents)}</td><td>${fmt(o.shipping_cents)}</td><td>${fmt(o.tax_cents)}</td><td><strong>${fmt(o.total_cents)}</strong></td></tr>`).join('')}</table>`
      : `<div class="empty">${t('orders_empty')}</div>`;
  }
  if (tab === 'traffic') {
    const d = await api('/api/seller/traffic', { headers: sellerHeaders() });
    const s = d.stats;
    const maxH = Math.max(1, ...d.hourly.map((h) => h.views));
    const maxLot = Math.max(1, ...d.by_lot.map((l) => l.views));
    const maxState = Math.max(1, ...d.by_state.map((x) => x.visitors));
    body.innerHTML = `
      <div class="stat-grid">
        <div class="stat"><div class="num">${s.today_visitors}</div><div class="lbl">${t('t_today')}</div></div>
        <div class="stat"><div class="num">${s.total_visitors}</div><div class="lbl">${t('t_total')}</div></div>
        <div class="stat"><div class="num">${s.page_views}</div><div class="lbl">${t('t_pages')}</div></div>
        <div class="stat"><div class="num">${s.lot_views}</div><div class="lbl">${t('t_lots')}</div></div>
        <div class="stat"><div class="num">${s.bids}</div><div class="lbl">${t('t_bids')}</div></div>
      </div>
      <div class="panel"><h3 style="margin-top:0">${t('t_hours')}</h3>
        <div class="bars">${d.hourly.map((h) => `<div class="bar" style="height:${Math.max(2, (h.views / maxH) * 100)}%" data-tip="${h.hour}:00 · ${h.views} ${t('views')} · ${h.visitors} ${t('visitors')}"></div>`).join('')}</div>
        <div class="bar-hours">${d.hourly.map((h) => `<span>${h.hour % 3 === 0 ? h.hour : ''}</span>`).join('')}</div>
      </div>
      <div class="panel" style="margin-top:16px"><h3 style="margin-top:0">${t('t_by_lot')}</h3>
        ${d.by_lot.map((l, i) => `<div class="rank-row">
          ${l.cover ? `<img class="thumb" src="${esc(l.cover)}" alt="">` : '<span class="thumb"></span>'}
          <div class="grow"><div style="display:flex;justify-content:space-between;gap:10px"><span><strong>${i + 1}.</strong> ${esc(l.title)}</span>
          <span class="note">${l.views} ${t('views')} · <span style="color:var(--accent)">${l.bids} ${t('bids')}</span></span></div>
          <div class="track"><div class="fillb" style="width:${(l.views / maxLot) * 100}%"></div></div></div></div>`).join('') || `<p class="note">—</p>`}
      </div>
      <div class="panel" style="margin-top:16px"><h3 style="margin-top:0">${t('t_by_state')}</h3>
        ${d.by_state.map((x) => `<div class="hbar-row"><span class="name">${esc(x.state)}</span>
          <div class="track"><div class="fillb" style="width:${(x.visitors / maxState) * 100}%"></div></div>
          <span class="note">${x.visitors} ${t('visitors')} · ${x.views} ${t('views')}</span></div>`).join('') || `<p class="note">—</p>`}
      </div>`;
  }
}

/* ------------------------------- router ------------------------------ */
function setNav(key) { $$('.main-nav a').forEach((a) => a.classList.toggle('active', a.dataset.nav === key)); }
async function render() {
  const hash = location.hash || '#/';
  const parts = hash.replace(/^#\//, '').split('/');
  window.scrollTo(0, 0);
  try {
    if (hash === '#/' || hash === '#') { setNav('home'); await pageHome(); }
    else if (parts[0] === 'lot') { setNav('home'); await pageLot(Number(parts[1])); }
    else if (parts[0] === 'my-bids') { setNav('mybids'); await pageMyBids(); }
    else if (parts[0] === 'rules') { setNav('rules'); pageRules(); }
    else if (parts[0] === 'contact') { setNav(''); pageContact(); }
    else if (parts[0] === 'my-messages') { setNav('mymsg'); pageMyMessages(); }
    else if (parts[0] === 'checkout') { setNav('mybids'); await pageCheckout(Number(parts[1])); }
    else if (parts[0] === 'seller') { setNav(''); await pageSeller(); }
    else { setNav('home'); await pageHome(); }
  } catch (err) {
    app.innerHTML = `<div class="empty">Error: ${esc(err.message || 'failed to load')}</div>`;
  }
}
window.addEventListener('hashchange', render);
applyI18nStatic();
render();
